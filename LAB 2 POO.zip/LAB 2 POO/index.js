const form = document.querySelector('form');

form.addEventListener('submit', function(event) {
  event.preventDefault();

  const ciudadDeOrigen = document.getElementById('ciudadDeOrigen').value;
  const ciudadDeDestino = document.getElementById('ciudadDeDestino').value;
  const fechaDeViaje = document.getElementById('fechaDeViaje').value;
  const horaDeSalida = document.getElementById('horaDeSalida').value;

  const totalPagar = CalcularTotal(ciudadDeOrigen, ciudadDeDestino, fechaDeViaje, horaDeSalida);
  document.getElementById('totalPagar').value = "$"+totalPagar.toFixed(2);
});
       
function CalcularTotal( ciudadDeOrigen, ciudadDeDestino, fechaDeViaje, horaDeSalida ) {
  let tarifaCiudad = 0;
  let tarifaDia = 0;
  let tarifaHora = 0;
  let dia = new Date(fechaDeViaje).getDay();
  let hora = Number(horaDeSalida);

  if ( ciudadDeOrigen !=ciudadDeDestino ) {
    tarifaCiudad = 50;
  }

  if ( dia == 4 || dia == 5 || dia == 6 ){
    tarifaDia = 100;
  }

  if ( ( hora >= 7 && hora <= 9 ) || ( hora >= 16 && hora <= 18 ) ) {
    tarifaHora = 75;
  }

  return 200 + tarifaCiudad + tarifaDia + tarifaHora;
}